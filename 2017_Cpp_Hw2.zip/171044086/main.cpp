/*30.09.2017 */
/*HW01_Hamza_Yoğurtcuoğlu_171044086*/
/*Connect 4 oyunu user1 vs user2 ve user1 vs normal level computer şeklinde oynanır*/
#include <iostream>
#include<cstdlib>
using namespace std;
void user1(char[][20], int,char &);
void user2(char[][20], int,char &);
void computer(char[][20], int,char &);
void choosingversus(char & );
void creatingboardletter(int);
void printboard(int,char[][20]);
int choosingsize(void);
bool verticalcompare(char [][20],int);
bool horizontalcompare(char[][20],int);
bool rightupdiagonalcompare(char[][20],int);
bool leftupdiagonalcompare(char[][20],int);
bool rightdowndiagonalcompare(char[][20],int);
bool leftdowndiagonalcompare(char[][20],int);
char  letter[20]={'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T'};
int main() {
    srand(time(NULL));
char versus;    
int size;
    size=choosingsize();
    choosingversus(versus);
    char  boardpoint[20][20]={},letter;
    for(int vert=0;vert<20;vert++)
        for(int horiz=0;horiz<20;horiz++)
            boardpoint[vert][horiz]='.';
    creatingboardletter(size);
    printboard(size,boardpoint) ;
    /*tahtanın max. kutu sayısı kadar kullanıcı ve computer arasındaki hamle sıralamasını*/
    /*for döngüsü max kaç kere oyunun döneceğini gösterir*/
    /*Eğer kullanıcı 1 sayısını girerse kullanıcı1 kullanıcı2 arası oyun başlar*/
    if(versus=='P')
    {for(int temp=0;(size*size)/2>temp;temp++) {
            cout<<"\n";
            user1(boardpoint,size,letter);
            cout<<"\n";
            if(horizontalcompare(boardpoint,size))
            {creatingboardletter(size);
                cout<<"\n";
                printboard(size,boardpoint);
                cout<<"\n";
                cout<<"x won,Congratulations :)";
                return 0;}
            if(verticalcompare(boardpoint,size))
            {creatingboardletter(size);
                cout<<"\n";
                printboard(size,boardpoint);
                cout<<"\n";
                cout<<"x won,Congratulations :)";
                return 0;}
            if(leftupdiagonalcompare(boardpoint,size))
            {creatingboardletter(size);
                cout<<"\n";
                printboard(size,boardpoint);
                cout<<"\n";
                cout<<"x won,Congratulation :)";
                return 0;}
            if(rightupdiagonalcompare(boardpoint,size))
            {creatingboardletter(size);
                cout<<"\n";
                printboard(size,boardpoint);
                cout<<"\n";
                cout<<"x won,Congratulation :)";
                return 0;}
            if(leftdowndiagonalcompare(boardpoint,size))
            {creatingboardletter(size);
                cout<<"\n";
                printboard(size,boardpoint);
                cout<<"\n";
                cout<<"x won,Congratulations";
                return 0; }
            if(rightdowndiagonalcompare(boardpoint,size))
            {creatingboardletter(size);
                cout<<"\n";
                printboard(size,boardpoint);
                cout<<"\n";
                cout<<"x won,Conratulations;";
                return 0;}
            creatingboardletter(size);
            cout<<"\n";
            printboard(size,boardpoint);
            cout<<"\n";
            user2(boardpoint,size,letter);
            if(horizontalcompare(boardpoint,size))
            {creatingboardletter(size);
                cout<<"\n";
                printboard(size,boardpoint);
                cout<<"\n";
                cout<<"o won,Congratulation :)";
                return 0;}
            if(verticalcompare(boardpoint,size))
            {creatingboardletter(size);
                cout<<"\n";
                printboard(size,boardpoint);
                cout<<"\n";
                cout<<"o won,Congratulations :)";
                return 0;}
            if(rightupdiagonalcompare(boardpoint,size))
            {creatingboardletter(size);
                cout<<"\n";
                printboard(size,boardpoint);
                cout<<"\n";
                cout<<"o won,Congratulation :)";
                return 0;}
            if(leftupdiagonalcompare(boardpoint,size))
            {creatingboardletter(size);
                cout<<"\n";
                printboard(size,boardpoint);
                cout<<"\n";
                cout<<"o won,Congratulations :)";
                return 0;}
            if(leftdowndiagonalcompare(boardpoint,size))
            {creatingboardletter(size);
                cout<<"\n";
                printboard(size,boardpoint);
                cout<<"\n";
                cout<<"o won,Congratulations";
                return 0; }
            if(rightdowndiagonalcompare(boardpoint,size))
            {creatingboardletter(size);
                cout<<"\n";
                printboard(size,boardpoint);
                cout<<"\n";
                cout<<"o won,Conratulations;";
                return 0;}
            creatingboardletter(size);
            cout<<"\n";
            printboard(size,boardpoint);
            cout<<"\n"; }}
    /*for döngüsü hamle sayısını gösterir*/
    /*tahtanın max. kutu sayısı kadar kullanıcı ve computer arasındaki hamle sıralamasını*/
    /*Eğer kullanıcı 2 sayısını girerse kullanıcı bilgisayar arası oyun başlar*/
    if(versus=='C'){
        for (int temp = 0; (size * size)/2 > temp; temp++) {
            cout<<"\n";
            user1(boardpoint, size,letter);
            if(horizontalcompare(boardpoint,size))
            {creatingboardletter(size);
                cout<<"\n";
                printboard(size,boardpoint);
                cout<<"\n";
                cout<<"x won,Congratulations :)";
                return 0;}
            if(verticalcompare(boardpoint,size))
            {creatingboardletter(size);
                cout<<"\n";
                printboard(size,boardpoint);
                cout<<"\n";
                cout<<"x won,Congratulations :)";
                return 0;}
            if(rightupdiagonalcompare(boardpoint,size))
            {creatingboardletter(size);
                cout<<"\n";
                printboard(size,boardpoint);
                cout<<"\n";
                cout<<"x won,Congratulation :)";
                return 0;}
            if(leftupdiagonalcompare(boardpoint,size))
            {creatingboardletter(size);
                cout<<"\n";
                printboard(size,boardpoint);
                cout<<"\n";
                cout<<"x won,Congratulations :)";
                return 0;}
            if(leftdowndiagonalcompare(boardpoint,size))
            {creatingboardletter(size);
                cout<<"\n";
                printboard(size,boardpoint);
                cout<<"\n";
                cout<<"x won,Congratulations";
                return 0; }
            if(rightdowndiagonalcompare(boardpoint,size))
            {creatingboardletter(size);
                cout<<"\n";
                printboard(size,boardpoint);
                cout<<"\n";
                cout<<"x won,Conratulations;";
                return 0;}
            cout<<"\n";
            creatingboardletter(size);
            cout<<"\n";
            printboard(size, boardpoint);
            cout<<"\n";
            computer(boardpoint, size,letter);
            if(horizontalcompare(boardpoint,size))
            {creatingboardletter(size);
                cout<<"\n";
                printboard(size,boardpoint);
                cout<<"\n";
                cout<<"o won,Congratulation :)";
                return 0;}
            if(verticalcompare(boardpoint,size))
            {creatingboardletter(size);
                cout<<"\n";
                printboard(size,boardpoint);
                cout<<"\n";
                cout<<"o won,Congratulations :)";
                return 0;}
            if(rightupdiagonalcompare(boardpoint,size))
            {creatingboardletter(size);
                cout<<"\n";
                printboard(size,boardpoint);
                cout<<"\n";
                cout<<"o won,Congratulation :)";
                return 0;}
            if(leftupdiagonalcompare(boardpoint,size))
            {creatingboardletter(size);
                cout<<"\n";
                printboard(size,boardpoint);
                cout<<"\n";
                cout<<"o won,Congratulations :)";
                return 0;}
            if(leftdowndiagonalcompare(boardpoint,size))
            {creatingboardletter(size);
                cout<<"\n";
                printboard(size,boardpoint);
                cout<<"\n";
                cout<<"o won,Congratulations";
                return 0; }
            if(rightdowndiagonalcompare(boardpoint,size))
            {creatingboardletter(size);
                cout<<"\n";
                printboard(size,boardpoint);
                cout<<"\n";
                cout<<"o won,Conratulations;";
                return 0;}
            cout<<"\n";
            creatingboardletter(size);
            cout<<"\n";
            printboard(size, boardpoint);
            cout<<"\n"; }
    }cout<<"Nobody won";
    return 0; }
/*Ekrana boardun alfabedik sıralamasını yazar*/
void creatingboardletter (int size)
{ for(int i=0;i<size;i++)
    {cout<<letter[i];
        cout<<" ";}
}/*Ekrana İstenilen Boyuttaki Tahtayı Çizer*/
void printboard(int size,char boardpoint[][20])
{ for(int i=0;i<size;i++)
    {    cout<<"\n";
        for(int j=0;j<size;j++)
            cout<<boardpoint[i][j]<<" ";}}
/*İstenilen Boyutu Kullanıcıdan Alınmasını Sağlar*/
int choosingsize(void)
{ int static size;
    cout<<"Enter a even size where should be between 4x4,6x6..20x20."<<endl;
    cin>>size;
    cin.clear();
    cin.ignore(1000,'\n');
    if(!((size<21,size>3)&&size%2==0))
    { return choosingsize() ;}  else return size;}
/*Kime Karşı Oynamak İstediğini Belirten Fonksiyon*/
void choosingversus(char &versus)
{    cout<<"Enter Your Section: 1) User1 vs. User2 for (P) button : \n"<<"\t\t"<<"    2) User1 vs. Computer for (C) button :  ";
    cin>>versus;
    cin.clear();
    cin.ignore(1000,'\n');
    switch(versus)
    { case 'P':break;
        case 'C':break;
        default:return choosingversus(versus); }}
/*Birinci kullanıcının hamlesini kontrol eden fonksiyon*/
void user1(char boardpoint [][20],int size,char & letter)
{ cout<<"User1 enter a letter :";
    cin>>letter;
    cin.clear();
    cin.ignore(1000,'\n');
    if (!(sizeof(letter)==sizeof(char)))
        user1(boardpoint,size,letter);
    else if(size<letter-64)
        return user1(boardpoint,size,letter);
    switch (letter){
        case 'A': for(int i=size;i>0;i--)
                if(boardpoint[i-1][0]=='.')
                {       boardpoint[i-1][0]='x';
                    return ; }   return user1(boardpoint,size,letter);
        case 'B': for(int i=size;i>0;i--)
                if(boardpoint[i-1][1]=='.')
                {       boardpoint[i-1][1]='x';
                    return ; }   return user1(boardpoint,size,letter);
        case 'C': for(int i=size;i>0;i--)
                if(boardpoint[i-1][2]=='.')
                {       boardpoint[i-1][2]='x';
                    return ; }   return user1(boardpoint,size,letter);
        case 'D': for(int i=size;i>0;i--)
                if(boardpoint[i-1][3]=='.')
                {       boardpoint[i-1][3]='x';
                    return ; }   return user1(boardpoint,size,letter);
        case 'E': for(int i=size;i>0;i--)
                if(boardpoint[i-1][4]=='.')
                {       boardpoint[i-1][4]='x';
                    return ; }   return user1(boardpoint,size,letter);
        case 'F': for(int i=size;i>0;i--)
                if(boardpoint[i-1][5]=='.')
                {       boardpoint[i-1][5]='x';
                    return ; }   return user1(boardpoint,size,letter);
        case 'G': for(int i=size;i>0;i--)
                if(boardpoint[i-1][6]=='.')
                {       boardpoint[i-1][6]='x';
                    return ; }   return user1(boardpoint,size,letter);
        case 'H': for(int i=size;i>0;i--)
                if(boardpoint[i-1][7]=='.')
                {       boardpoint[i-1][7]='x';
                    return ; }   return user1(boardpoint,size,letter);
        case 'I': for(int i=size;i>0;i--)
                if(boardpoint[i-1][8]=='.')
                {       boardpoint[i-1][8]='x';
                    return ; }   return user1(boardpoint,size,letter);
        case 'J': for(int i=size;i>0;i--)
                if(boardpoint[i-1][9]=='.')
                {       boardpoint[i-1][9]='x';
                    return ; }   return user1(boardpoint,size,letter);
        case 'K': for(int i=size;i>0;i--)
                if(boardpoint[i-1][10]=='.')
                {       boardpoint[i-1][10]='x';
                    return ; }   return user1(boardpoint,size,letter);
        case 'L': for(int i=size;i>0;i--)
                if(boardpoint[i-1][11]=='.')
                {       boardpoint[i-1][11]='x';
                    return ; }   return user1(boardpoint,size,letter);
        case 'M': for(int i=size;i>0;i--)
                if(boardpoint[i-1][12]=='.')
                {       boardpoint[i-1][12]='x';
                    return ; }   return user1(boardpoint,size,letter);
        case 'N': for(int i=size;i>0;i--)
                if(boardpoint[i-1][13]=='.')
                {       boardpoint[i-1][13]='x';
                    return ; }   return user1(boardpoint,size,letter);
        case 'O': for(int i=size;i>0;i--)
                if(boardpoint[i-1][14]=='.')
                {       boardpoint[i-1][14]='x';
                    return ; }   return user1(boardpoint,size,letter);
        case 'P': for(int i=size;i>0;i--)
                if(boardpoint[i-1][15]=='.')
                {       boardpoint[i-1][15]='x';
                    return ; }   return user1(boardpoint,size,letter);
        case 'Q': for(int i=size;i>0;i--)
                if(boardpoint[i-1][16]=='.')
                {       boardpoint[i-1][16]='x';
                    return ; }   return user1(boardpoint,size,letter);
        case 'R': for(int i=size;i>0;i--)
                if(boardpoint[i-1][17]=='.')
                {       boardpoint[i-1][17]='x';
                    return ; }   return user1(boardpoint,size,letter);
        case 'S': for(int i=size;i>0;i--)
                if(boardpoint[i-1][18]=='.')
                {       boardpoint[i-1][18]='x';
                    return ; }   return user1(boardpoint,size,letter);
        case 'T': for(int i=size;i>0;i--)
                if(boardpoint[i-1][19]=='.')
                {       boardpoint[i-1][19]='x';
                    return ; }   return user1(boardpoint,size,letter);
        default: return user1(boardpoint,size,letter); }}
/*İkinci kullanıcının hamlesini control eden fonksiyon*/
void user2(char boardpoint[][20],int size, char & letter)
{ cout<<"\nUser2 enters a letter :";
    cin>>letter;
    cin.clear();
    cin.ignore(1000,'\n');
    if (!(sizeof(letter)==sizeof(char)))
        user2(boardpoint,size,letter);
    if(size<letter-64)
        return user2(boardpoint,size,letter);
    switch (letter){
        case 'A': for(int i=size;i>0;i--)
                if(boardpoint[i-1][0]=='.')
                {       boardpoint[i-1][0]='o';
                    return ; }   return user2(boardpoint,size,letter);
        case 'B': for(int i=size;i>0;i--)
                if(boardpoint[i-1][1]=='.')
                {       boardpoint[i-1][1]='o';
                    return ; }   return user2(boardpoint,size,letter);
        case 'C': for(int i=size;i>0;i--)
                if(boardpoint[i-1][2]=='.')
                {       boardpoint[i-1][2]='o';
                    return ; }   return user2(boardpoint,size,letter);
        case 'D': for(int i=size;i>0;i--)
                if(boardpoint[i-1][3]=='.')
                {       boardpoint[i-1][3]='o';
                    return ; }   return user2(boardpoint,size,letter);
        case 'E': for(int i=size;i>0;i--)
                if(boardpoint[i-1][4]=='.')
                {       boardpoint[i-1][4]='o';
                    return ; }   return user2(boardpoint,size,letter);
        case 'F': for(int i=size;i>0;i--)
                if(boardpoint[i-1][5]=='.')
                {       boardpoint[i-1][5]='o';
                    return ; }   return user2(boardpoint,size,letter);
        case 'G': for(int i=size;i>0;i--)
                if(boardpoint[i-1][6]=='.')
                {       boardpoint[i-1][6]='o';
                    return ; }   return user2(boardpoint,size,letter);
        case 'H': for(int i=size;i>0;i--)
                if(boardpoint[i-1][7]=='.')
                {       boardpoint[i-1][7]='o';
                    return ; }   return user2(boardpoint,size,letter);
        case 'I': for(int i=size;i>0;i--)
                if(boardpoint[i-1][8]=='.')
                {       boardpoint[i-1][8]='o';
                    return ; }   return user2(boardpoint,size,letter);
        case 'J': for(int i=size;i>0;i--)
                if(boardpoint[i-1][9]=='.')
                {       boardpoint[i-1][9]='o';
                    return ; }   return user2(boardpoint,size,letter);
        case 'K': for(int i=size;i>0;i--)
                if(boardpoint[i-1][10]=='.')
                {       boardpoint[i-1][10]='o';
                    return ; }   return user2(boardpoint,size,letter);
        case 'L': for(int i=size;i>0;i--)
                if(boardpoint[i-1][11]=='.')
                {       boardpoint[i-1][11]='o';
                    return ; }   return user2(boardpoint,size,letter);
        case 'M': for(int i=size;i>0;i--)
                if(boardpoint[i-1][12]=='.')
                {       boardpoint[i-1][12]='o';
                    return ; }   return user2(boardpoint,size,letter);
        case 'N': for(int i=size;i>0;i--)
                if(boardpoint[i-1][13]=='.')
                {       boardpoint[i-1][13]='o';
                    return ; }   return user2(boardpoint,size,letter);
        case 'O': for(int i=size;i>0;i--)
                if(boardpoint[i-1][14]=='.')
                {       boardpoint[i-1][14]='o';
                    return ; }   return user2(boardpoint,size,letter);
        case 'P': for(int i=size;i>0;i--)
                if(boardpoint[i-1][15]=='.')
                {       boardpoint[i-1][15]='o';
                    return ; }   return user2(boardpoint,size,letter);
        case 'Q': for(int i=size;i>0;i--)
                if(boardpoint[i-1][16]=='.')
                {       boardpoint[i-1][16]='o';
                    return ; }   return user2(boardpoint,size,letter);
        case 'R': for(int i=size;i>0;i--)
                if(boardpoint[i-1][17]=='.')
                {       boardpoint[i-1][17]= 'o';
                    return ; }   return user2(boardpoint,size,letter);
        case 'S': for(int i=size;i>0;i--)
                if(boardpoint[i-1][18]=='.')
                {       boardpoint[i-1][18]='o';
                    return ; }   return user2(boardpoint,size,letter);
        case 'T': for(int i=size;i>0;i--)
                if(boardpoint[i-1][19]=='.')
                {       boardpoint[i-1][19]='o';
                    return ; }   return user2(boardpoint,size,letter);
        default: return user2(boardpoint,size,letter); }}
/*Bilgisayarın yapacağı hamleleri control eden fonksiyon*/
void computer(char boardpoint[][20],int size,char & letter)
{ char temp;
    temp=letter;
    letter=rand()%20+65;
    cin.clear();
    if(!(letter==temp||letter-temp==1||letter-temp==-1))
        return computer(boardpoint,size,temp);
    else if(size<letter-64)
        return computer(boardpoint,size,temp);
    switch (letter){
        case 'A': for(int i=size;i>0;i--)
                if(boardpoint[i-1][0]=='.')
                {       boardpoint[i-1][0]='o';
                    return ; }   return computer(boardpoint,size,letter);
        case 'B': for(int i=size;i>0;i--)
                if(boardpoint[i-1][1]=='.')
                {       boardpoint[i-1][1]='o';
                    return ; }   return computer(boardpoint,size,letter);
        case 'C': for(int i=size;i>0;i--)
                if(boardpoint[i-1][2]=='.')
                {       boardpoint[i-1][2]='o';
                    return ; }   return computer(boardpoint,size,letter);
        case 'D': for(int i=size;i>0;i--)
                if(boardpoint[i-1][3]=='.')
                {       boardpoint[i-1][3]='o';
                    return ; }   return computer(boardpoint,size,letter);
        case 'E': for(int i=size;i>0;i--)
                if(boardpoint[i-1][4]=='.')
                {       boardpoint[i-1][4]='o';
                    return ; }   return computer(boardpoint,size,letter);
        case 'F': for(int i=size;i>0;i--)
                if(boardpoint[i-1][5]=='.')
                {       boardpoint[i-1][5]='o';
                    return ; }   return computer(boardpoint,size,letter);
        case 'G': for(int i=size;i>0;i--)
                if(boardpoint[i-1][6]=='.')
                {       boardpoint[i-1][6]='o';
                    return ; }   return computer(boardpoint,size,letter);
        case 'H': for(int i=size;i>0;i--)
                if(boardpoint[i-1][7]=='.')
                {       boardpoint[i-1][7]='o';
                    return ; }   return computer(boardpoint,size,letter);
        case 'I': for(int i=size;i>0;i--)
                if(boardpoint[i-1][8]=='.')
                {       boardpoint[i-1][8]='o';
                    return ; }   return computer(boardpoint,size,letter);
        case 'J': for(int i=size;i>0;i--)
                if(boardpoint[i-1][9]=='.')
                {       boardpoint[i-1][9]='o';
                    return ; }   return computer(boardpoint,size,letter);
        case 'K': for(int i=size;i>0;i--)
                if(boardpoint[i-1][10]=='.')
                {       boardpoint[i-1][10]='o';
                    return ; }   return computer(boardpoint,size,letter);
        case 'L': for(int i=size;i>0;i--)
                if(boardpoint[i-1][11]=='.')
                {       boardpoint[i-1][11]='o';
                    return ; }   return computer(boardpoint,size,letter);
        case 'M': for(int i=size;i>0;i--)
                if(boardpoint[i-1][12]=='.')
                {       boardpoint[i-1][12]='o';
                    return ; }   return computer(boardpoint,size,letter);
        case 'N': for(int i=size;i>0;i--)
                if(boardpoint[i-1][13]=='.')
                {       boardpoint[i-1][13]='o';
                    return ; }   return computer(boardpoint,size,letter);
        case 'O': for(int i=size;i>0;i--)
                if(boardpoint[i-1][14]=='.')
                {       boardpoint[i-1][14]='o';
                    return ; }   return computer(boardpoint,size,letter);
        case 'P': for(int i=size;i>0;i--)
                if(boardpoint[i-1][15]=='.')
                {       boardpoint[i-1][15]='o';
                    return ; }   return computer(boardpoint,size,letter);
        case 'Q': for(int i=size;i>0;i--)
                if(boardpoint[i-1][16]=='.')
                {       boardpoint[i-1][16]='o';
                    return ; }   return computer(boardpoint,size,letter);
        case 'R': for(int i=size;i>0;i--)
                if(boardpoint[i-1][17]=='.')
                {       boardpoint[i-1][17]= 'o';
                    return ; }   return computer(boardpoint,size,letter);
        case 'S': for(int i=size;i>0;i--)
                if(boardpoint[i-1][18]=='.')
                {       boardpoint[i-1][18]='o';
                    return ; }   return computer(boardpoint,size,letter);
        case 'T': for(int i=size;i>0;i--)
                if(boardpoint[i-1][19]=='.')
                {       boardpoint[i-1][19]='o';
                    return ; }   return computer(boardpoint,size,letter);
        default: return computer(boardpoint,size,letter); }}
/*Herhangi kullanıcıdan birinin dikey şekilde üstüste dörtlü sıralamasını kontrol eden fonksiyon*/
bool verticalcompare(char boardpoint [][20],int size)
{
    for(int i=0;i<=size;i++)
    {
        for(int j=size-1;j>=0;j--)
        {int counter=0;
            if (boardpoint[j][i]=='x')
            {for (int control=j-1;control>j-4;control--)
                {if(boardpoint[control][i]=='x')counter++;
                    if(counter==3)
                        return true;}}}}
    for(int i=0;i<=size;i++)
    { for(int j=size-1;j>=0;j--)
        {int counter=0;
            if (boardpoint[j][i]=='o')
            {for (int control=j-1;control>j-4;control--)
                {if(boardpoint[control][i]=='o')counter++;
                    if(counter==3)
                        return true;}}}} return false; }
/*Herhangi kullanıcıdan birinin yatay şekilde yanyana dörtlü sıralamasını kontrol eden fonksiyon*/
bool horizontalcompare(char boardpoint[][20],int size)
{ for(int i=size-1;i>=0;i--)
    { for(int j=0;j<=size;j++) {int counter=0;
            if(boardpoint[i][j]=='x')
            {for(int control=j+1;control<j+4;control++)
                { if(boardpoint[i][control]=='x') counter++;
                    if(counter==3)
                        return true;}}}}
    for(int i=size-1;i>=0;i--) {
        for(int j=0;j<=size;j++) {int counter=0;
            if(boardpoint[i][j]=='o')
            {for(int control=j+1;control<j+4;control++)
                { if(boardpoint[i][control]=='o') counter++;
                    if(counter==3)
                        return true;}}}}return false;       }
/*Haritanın sol üstü çapraz olarak kontrol eden foksiyon*/
bool leftupdiagonalcompare (char boardpoint[][20],int size)
{ for(int a=0;a<size;a++)
    {int j=-1;
        for(int k=size-1-a;k>=0;k--)
        {if (boardpoint[k][j=j+1]=='x')
            {int counter=0;
                int f=j;
                for(int control=k-1;control>k-4;control--)
                { if(boardpoint[control][f=f+1]=='x')
                        counter++;
                    if(counter==3)
                        return true; }}}}
    for(int a=0;a<size;a++) {
        int j = -1;
        for (int k = size - 1 - a; k >= 0; k--) {
            if (boardpoint[k][j = j + 1] == 'o') {
                int counter = 0;
                int f = j;
                for (int control = k - 1; control > k - 4; control--) {
                    if (boardpoint[control][f = f + 1] == 'o')
                        counter++;
                    if (counter == 3)
                        return true; }}}} return false; }
/*Haritanın sağ üstü çapraz olarak kontrol eder*/
bool rightupdiagonalcompare(char boardpoint[][20],int size)
{ for(int a=0;a<size;a++)
    {int j=size;
        for(int k=size-1-a;k>=0;k--)
        {if (boardpoint[k][j=j-1]=='x')
            {int counter=0;
                int f=j;
                for(int control=k-1;control>k-4;control--)
                { if(boardpoint[control][f=f-1]=='x')
                        counter++;
                    if(counter==3)
                        return true; }}}}
    for(int a=0;a<size;a++)
    {int j=size;
        for(int k=size-1-a;k>=0;k--)
        {if (boardpoint[k][j=j-1]=='o')
            {int counter=0;
                int f=j;
                for(int control=k-1;control>k-4;control--)
                { if(boardpoint[control][f=f-1]=='o')
                        counter++;
                    if(counter==3)
                        return true; }}}}return false; }
/*Haritanın sağ aşşağıyı çapraz olarak kontrol eder*/
bool rightdowndiagonalcompare(char boardpoint[][20],int size)
{ for(int a=0;a<size;a++)
    {int j=size;
        for(int k=0+a;size>k;k++)
        {if (boardpoint[k][j=j-1]=='x')
            {int counter=0;
                int f=j;
                for(int control=k+1;control<k+4;control++)
                { if(boardpoint[control][f=f-1]=='x')
                        counter++;
                    if(counter==3)
                        return true; }}}}
    for(int a=0;a<size;a++)
    {int j=size;
        for(int k=0+a;size>k;k++)
        {if (boardpoint[k][j=j-1-a]=='o')
            {int counter=0;
                int f=j;
                for(int control=k+1;control<k+4;control++)
                {
                    if(boardpoint[control][f=f-1]=='o')
                        counter++;
                    if(counter==3)
                        return true; }}}}return false; }
/*Haritanın sol aşşağıyı çapraz olarak kontrol eder*/
bool leftdowndiagonalcompare(char boardpoint[][20],int size)
{ for(int a=0;a<size;a++)
    {int j=-1;
        for(int k=0+a;k<=size;k++)
        {if (boardpoint[k][j=j+1]=='x')
            {int counter=0;
                int f=j;
                for(int control=k+1;control<k+4;control++)
                { if(boardpoint[control][f=f+1]=='x')
                        counter++;
                    if(counter==3)
                        return true; }}}
    }for(int a=0;a<size;a++)
    {int j=-1;
        for(int k=0+a;k<=size;k++)
        {if (boardpoint[k][j=j+1]=='o')
            {int counter=0;
                int f=j;
                for(int control=k+1;control<k+4;control++)
                { if(boardpoint[control][f=f+1]=='o')
                        counter++;
                    if(counter==3)
                        return true; }}}}return false; }

